CREATE DATABASE Super_store;
USE Super_store;

-- Creating table Orders
 
CREATE TABLE Orders(
RowID INT PRIMARY KEY,
    OrderID VARCHAR(20),
    OrderDate DATE,
    ShipDate DATE,
    ShipMode VARCHAR(50),
    CustomerID VARCHAR(100),
    CustomerName VARCHAR(100),
    Segment VARCHAR(220),
    Country VARCHAR(225),
    City VARCHAR(225),
    State VARCHAR(225),
    PostalCode VARCHAR(225),
    Region VARCHAR(50),
    ProductID VARCHAR(20),
    Category VARCHAR(50),
    SubCategory VARCHAR(50),
    Sales INT,
    Quantity INT,
    Discount INT,
    Profit INT
);

-- Loding the data from CSV file to Database in the table

LOAD DATA INFILE 'C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Uploads\\US Superstore data.csv'
INTO TABLE Orders
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;



SELECT * FROM Orders WHERE Category='Furniture';    -- Select those recordes in which Category is Furniture

SELECT Category, SUM(Sales) AS TotalSales
FROM Orders                                           -- Display the sum of sales as Total sales of all categories 
GROUP BY Category;

SELECT Region, AVG(Sales) AS AvgSales
FROM Orders                                              -- Display the average sales by regions
GROUP BY Region;


-- Creating new table Customers

CREATE TABLE Customers (
    CustomerID VARCHAR(20) PRIMARY KEY,
    CustomerName VARCHAR(100),
    Region VARCHAR(50)
);


INSERT INTO Customers (CustomerID, CustomerName, Region) VALUES
('1', 'John Doe', 'East'),
('2', 'Jane Smith', 'West'),
('3', 'Emily Johnson', 'South'),
('4', 'Michael Brown', 'Central');

SELECT Orders.CustomerID, Orders.CustomerName, Orders.Segment, Orders.Country, Orders.City, Orders.State, Orders.PostalCode
FROM Orders                                                                                                                     -- Select all the data that is related to the customer
JOIN Customers ON Orders.Region = Customers.Region;


SELECT * FROM Orders;